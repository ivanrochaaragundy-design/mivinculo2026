//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-Dlb1YtKV.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: ["/"],
		preloads: ["/assets/index-Di4JZbnZ.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-Di4JZbnZ.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-D9TK9zUu.js"]
	}
} });
//#endregion
export { tsrStartManifest };
