import { i as __toESM } from "../_runtime.mjs";
import { K as require_react, b as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-BpXhRJpq.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var CHAPTERS = [
	{
		id: "verdad",
		num: "01",
		title: "De verdad",
		paragraphs: [
			"Te amo.",
			"Mucho. De verdad. No para llenar un silencio, ni para que suene bien al decirlo en voz alta.",
			"Te amo porque es lo más claro que me queda. Porque cuando estoy contigo, el resto se vuelve ruido y esto —tú— se queda."
		]
	},
	{
		id: "nuevo",
		num: "02",
		title: "Nuevo y hermoso",
		paragraphs: [
			"Todo lo que me haces sentir es nuevo.",
			"No es un eco de alguien más. No es una costumbre que ya conocía. Es otra luz, otra temperatura, otra manera de estar en el cuerpo.",
			"Hermoso de una forma que no sabía nombrar hasta que llegaste: como si el pecho se me quedara chico y, aun así, no quisiera que pare."
		]
	},
	{
		id: "mereces",
		num: "03",
		title: "Lo que mereces",
		paragraphs: [
			"Y hay algo que tengo que decirte, aunque me deje en el lugar más pequeño.",
			"Quizá yo no soy lo que mereces. Quizá no soy lo que buscas.",
			"No te lo digo para que me contradigas. Te lo digo porque te respeto demasiado para fingir que llego entero, listo, suficiente."
		]
	},
	{
		id: "paciencia",
		num: "04",
		title: "Paciencia",
		paragraphs: [
			"Hoy por hoy soy un desastre.",
			"No el de las películas. El de verdad: el que se desarma y todavía no sabe recoger todas las piezas.",
			"Si puedes, tenme paciencia. No te pido que me salves. Te pido tiempo. Un poco de calma mientras aprendo a sostenerme… y a sostenerte bien."
		]
	}
];
var VOWS = [
	{
		id: "mundo",
		word: "el mundo",
		line: "Los días comunes. La risa sin motivo. Una vida que huela a nosotros dos."
	},
	{
		id: "universo",
		word: "el universo",
		line: "Lo que todavía no conocemos. Los lugares, las versiones de mí que solo aparecen si estás tú."
	},
	{
		id: "infinito",
		word: "el infinito",
		line: "Quedarme. No un rato. Quedarme, y merecer que te quedes."
	}
];
var SONG_ID = "lg0TLCr2W0Q";
var SONG_URL = "https://youtu.be/lg0TLCr2W0Q?si=lgVa_TL9NXhwmrF_";
function useBackgroundSong() {
	const playerRef = (0, import_react.useRef)(null);
	const wantRef = (0, import_react.useRef)(true);
	const heardRef = (0, import_react.useRef)(false);
	const [audible, setAudible] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		let cancelled = false;
		const mount = () => {
			if (cancelled || playerRef.current || !window.YT?.Player) return;
			if (!document.getElementById("yt-bg")) return;
			playerRef.current = new window.YT.Player("yt-bg", {
				width: "128",
				height: "72",
				videoId: SONG_ID,
				playerVars: {
					autoplay: 1,
					loop: 1,
					playlist: SONG_ID,
					rel: 0,
					playsinline: 1,
					modestbranding: 1
				},
				events: {
					onReady: (event) => {
						if (heardRef.current) {
							event.target.unMute();
							event.target.setVolume(100);
						} else event.target.mute();
						if (wantRef.current) event.target.playVideo();
					},
					onStateChange: (event) => {
						if (event.data === 0 && wantRef.current) event.target.playVideo();
					}
				}
			});
		};
		if (window.YT?.Player) mount();
		else {
			const previous = window.onYouTubeIframeAPIReady;
			window.onYouTubeIframeAPIReady = () => {
				previous?.();
				mount();
			};
			if (!document.querySelector("script[data-yt-api]")) {
				const tag = document.createElement("script");
				tag.src = "https://www.youtube.com/iframe_api";
				tag.dataset.ytApi = "1";
				document.head.appendChild(tag);
			}
		}
		const arm = () => {
			if (!wantRef.current) return;
			heardRef.current = true;
			setAudible(true);
			const player = playerRef.current;
			if (!player) return;
			player.unMute();
			player.setVolume(100);
			player.playVideo();
		};
		window.addEventListener("pointerdown", arm);
		return () => {
			cancelled = true;
			window.removeEventListener("pointerdown", arm);
		};
	}, []);
	const play = () => {
		wantRef.current = true;
		heardRef.current = true;
		setAudible(true);
		const player = playerRef.current;
		if (!player) return;
		player.unMute();
		player.setVolume(100);
		player.playVideo();
	};
	const pause = () => {
		wantRef.current = false;
		heardRef.current = false;
		setAudible(false);
		playerRef.current?.pauseVideo();
	};
	return {
		play,
		pause,
		playing: audible
	};
}
var INDEX = [
	{
		id: "verdad",
		label: "De verdad"
	},
	{
		id: "nuevo",
		label: "Lo nuevo"
	},
	{
		id: "mereces",
		label: "La honestidad"
	},
	{
		id: "paciencia",
		label: "Paciencia"
	},
	{
		id: "infinito",
		label: "El infinito"
	},
	{
		id: "cancion",
		label: "La canción"
	}
];
function scrollToId(id) {
	const reduce = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
	document.getElementById(id)?.scrollIntoView({
		behavior: reduce ? "auto" : "smooth",
		block: "start"
	});
}
function Reveal({ children, className = "" }) {
	const ref = (0, import_react.useRef)(null);
	const [shown, setShown] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		const el = ref.current;
		if (!el) return;
		if (window.matchMedia("(prefers-reduced-motion: reduce)").matches) {
			setShown(true);
			return;
		}
		const observer = new IntersectionObserver(([entry]) => {
			if (entry?.isIntersecting) {
				setShown(true);
				observer.disconnect();
			}
		}, {
			threshold: .18,
			rootMargin: "0px 0px -6% 0px"
		});
		observer.observe(el);
		return () => observer.disconnect();
	}, []);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		ref,
		className: `reveal${shown ? " is-in" : ""}${className ? ` ${className}` : ""}`,
		children
	});
}
function Home() {
	const [progress, setProgress] = (0, import_react.useState)(0);
	const [open, setOpen] = (0, import_react.useState)({});
	const allOpen = VOWS.every((vow) => open[vow.id]);
	const song = useBackgroundSong();
	(0, import_react.useEffect)(() => {
		const onScroll = () => {
			const full = document.documentElement.scrollHeight - window.innerHeight;
			setProgress(full > 0 ? Math.min(1, window.scrollY / full) : 0);
		};
		onScroll();
		window.addEventListener("scroll", onScroll, { passive: true });
		return () => window.removeEventListener("scroll", onScroll);
	}, []);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "fixed inset-x-0 top-0 z-40 h-0.5 origin-left bg-rust",
			style: { transform: `scaleX(${progress})` },
			"aria-hidden": true
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "grid min-h-dvh lg:grid-cols-2",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "relative bg-night lg:min-h-dvh",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
					src: "/nosotros.jpg",
					alt: "Los dos, juntos, sonriendo",
					className: "cover-photo h-auto w-full lg:absolute lg:inset-0 lg:h-full"
				})
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-col justify-end bg-night px-6 pt-14 pb-28 text-paper sm:px-10 lg:justify-center lg:px-16 lg:py-20",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs font-medium tracking-widest text-brass uppercase",
						children: "Una carta, no un mensaje"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "mt-5 font-display text-6xl leading-none font-medium text-balance text-paper italic sm:text-7xl",
						children: "Para ti"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-6 max-w-sm text-lg leading-relaxed text-pretty text-paper/80",
						children: "Ordené lo que siento para que puedas leerlo despacio. Sin prisa. Sin tener que adivinar entre líneas."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: () => {
							song.play();
							scrollToId("carta");
						},
						className: "mt-10 inline-flex min-h-11 w-fit items-center rounded-seal bg-rust px-7 text-sm tracking-wide text-paper",
						children: "Leer la carta"
					})
				]
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("article", {
			id: "carta",
			className: "bg-paper text-ink",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "measure mx-auto max-w-xl px-6 py-20 sm:py-28",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-display text-2xl leading-snug text-balance italic sm:text-3xl",
						children: "Hay cosas que se me escapan cuando te hablo. Aquí no. Aquí te las dejo como son."
					}) }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
						className: "mt-12 flex flex-wrap gap-2",
						"aria-label": "Partes de la carta",
						children: INDEX.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: () => scrollToId(item.id),
							className: "inline-flex min-h-11 items-center rounded-seal border border-line px-4 text-sm text-muted",
							children: item.label
						}, item.id))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-16 space-y-20",
						children: CHAPTERS.map((chapter) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
							id: chapter.id,
							className: "scroll-mt-10",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Reveal, { children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-xs font-medium tracking-widest text-rust uppercase",
									children: chapter.num
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
									className: "mt-3 font-display text-4xl leading-none font-medium text-balance sm:text-5xl",
									children: chapter.title
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "rule mt-6" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "mt-8 space-y-5 text-lg leading-relaxed",
									children: chapter.paragraphs.map((paragraph) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: paragraph }, paragraph))
								})
							] })
						}, chapter.id))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, {
						className: "mt-20",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("blockquote", {
							className: "border-l border-brass pl-6",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "font-display text-3xl leading-snug text-balance italic sm:text-4xl",
								children: "«Contigo no quiero un pedazo. Contigo quiero todo.»"
							})
						})
					})
				]
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
			id: "infinito",
			className: "scroll-mt-10 bg-night text-paper",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mx-auto max-w-xl px-6 py-24 sm:py-32",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Reveal, { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs font-medium tracking-widest text-brass uppercase",
							children: "05 · Contigo quiero"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "mt-4 max-w-md font-display text-4xl leading-tight font-medium text-balance sm:text-5xl",
							children: "El mundo. El universo. El infinito."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-6 max-w-md leading-relaxed text-pretty text-paper/75",
							children: "Toca cada una. No es una lista: es lo que te estoy ofreciendo, de lo más cercano a lo que no termina."
						})
					] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "mt-12",
						children: VOWS.map((vow) => {
							const isOpen = Boolean(open[vow.id]);
							return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
								className: "border-t border-paper/15",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
									type: "button",
									"aria-expanded": isOpen,
									onClick: () => setOpen((current) => ({
										...current,
										[vow.id]: !current[vow.id]
									})),
									className: "flex min-h-16 w-full items-center justify-between gap-4 py-5 text-left",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "font-display text-4xl leading-none italic sm:text-5xl",
										children: vow.word
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-xs tracking-widest text-brass uppercase",
										children: isOpen ? "cerrar" : "abrir"
									})]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: `fold${isOpen ? " is-open" : ""}`,
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "fold-inner",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "max-w-md pb-6 leading-relaxed text-pretty text-paper/80",
											children: vow.line
										})
									})
								})]
							}, vow.id);
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: `fold${allOpen ? " is-open" : ""}`,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "fold-inner",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-8 font-display text-2xl leading-snug text-balance italic",
								children: "Si el infinito es demasiado grande para prometerlo de una vez, empecemos por quedarnos. Un día. Y otro. Y otro."
							})
						})
					})
				]
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
			id: "cierre",
			className: "bg-paper text-ink",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "measure mx-auto max-w-xl px-6 pt-20 pb-36 sm:pt-28 sm:pb-40",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("figure", {
						className: "print mx-auto max-w-sm",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
							src: "/nosotros.jpg",
							alt: "Los dos, en la misma noche",
							className: "aspect-4/5 w-full object-cover object-top"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("figcaption", {
							className: "mt-4 text-center font-display text-lg leading-snug italic",
							children: "Esta foto no alcanza a decirlo. Pero es verdad: estábamos ahí, juntos, y yo ya lo sabía."
						})]
					}) }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, {
						className: "mt-16",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							id: "cancion",
							className: "scroll-mt-10",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-xs font-medium tracking-widest text-rust uppercase",
									children: "06 · Para escuchar"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
									className: "mt-3 font-display text-4xl leading-none font-medium text-balance sm:text-5xl",
									children: "Entre vos y yo"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-6 text-lg leading-relaxed",
									children: "Va sonando de fondo mientras lees. Es de Los Caligaris: lo que yo quiero que sepas, dicho en una canción."
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
									href: SONG_URL,
									target: "_blank",
									rel: "noreferrer",
									className: "mt-6 inline-flex min-h-11 items-center text-sm tracking-wide text-rust underline decoration-brass underline-offset-4",
									children: "Abrir la canción"
								})
							]
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Reveal, {
						className: "mt-16",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "space-y-5 text-lg leading-relaxed",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "No te pido que me esperes para siempre." }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Te pido que, si algo de esto también es tuyo, me des el tiempo de poner en orden lo que soy. Porque contigo quiero el mundo, el universo y el infinito. Y quiero merecerlos." }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "No prometo ser perfecto. Prometo no querer esto a medias." })
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "rule mt-12" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "mt-8 font-display text-3xl leading-tight italic",
								children: [
									"Con todo lo que soy.",
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("br", {}),
									"Y con lo que todavía estoy aprendiendo a ser."
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-8 text-sm tracking-widest text-muted uppercase",
								children: "Para ti, de mí"
							})
						]
					})
				]
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("aside", {
			className: "fixed inset-x-3 bottom-3 z-30 border border-paper/15 bg-night text-paper shadow-none sm:inset-x-auto sm:right-4 sm:bottom-4 sm:w-96",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center gap-3 p-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "h-16 w-28 shrink-0 overflow-hidden bg-night-soft",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { id: "yt-bg" })
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "min-w-0 flex-1",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs font-medium tracking-widest text-brass uppercase",
							children: "De fondo"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "truncate font-display text-lg leading-tight italic",
							children: "Entre vos y yo"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: song.playing ? song.pause : song.play,
						className: "inline-flex min-h-11 shrink-0 items-center rounded-seal bg-rust px-4 text-sm tracking-wide text-paper",
						children: song.playing ? "Pausa" : "Escuchar"
					})
				]
			})
		})
	] });
}
//#endregion
export { Home as component };
