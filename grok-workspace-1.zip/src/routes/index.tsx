import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useRef, useState, type ReactNode } from "react";

export const Route = createFileRoute("/")({ component: Home });

const CHAPTERS = [
  {
    id: "verdad",
    num: "01",
    title: "De verdad",
    paragraphs: [
      "Te amo.",
      "Mucho. De verdad. No para llenar un silencio, ni para que suene bien al decirlo en voz alta.",
      "Te amo porque es lo más claro que me queda. Porque cuando estoy contigo, el resto se vuelve ruido y esto —tú— se queda.",
    ],
  },
  {
    id: "nuevo",
    num: "02",
    title: "Nuevo y hermoso",
    paragraphs: [
      "Todo lo que me haces sentir es nuevo.",
      "No es un eco de alguien más. No es una costumbre que ya conocía. Es otra luz, otra temperatura, otra manera de estar en el cuerpo.",
      "Hermoso de una forma que no sabía nombrar hasta que llegaste: como si el pecho se me quedara chico y, aun así, no quisiera que pare.",
    ],
  },
  {
    id: "mereces",
    num: "03",
    title: "Lo que mereces",
    paragraphs: [
      "Y hay algo que tengo que decirte, aunque me deje en el lugar más pequeño.",
      "Quizá yo no soy lo que mereces. Quizá no soy lo que buscas.",
      "No te lo digo para que me contradigas. Te lo digo porque te respeto demasiado para fingir que llego entero, listo, suficiente.",
    ],
  },
  {
    id: "paciencia",
    num: "04",
    title: "Paciencia",
    paragraphs: [
      "Hoy por hoy soy un desastre.",
      "No el de las películas. El de verdad: el que se desarma y todavía no sabe recoger todas las piezas.",
      "Si puedes, tenme paciencia. No te pido que me salves. Te pido tiempo. Un poco de calma mientras aprendo a sostenerme… y a sostenerte bien.",
    ],
  },
] as const;

const VOWS = [
  {
    id: "mundo",
    word: "el mundo",
    line: "Los días comunes. La risa sin motivo. Una vida que huela a nosotros dos.",
  },
  {
    id: "universo",
    word: "el universo",
    line: "Lo que todavía no conocemos. Los lugares, las versiones de mí que solo aparecen si estás tú.",
  },
  {
    id: "infinito",
    word: "el infinito",
    line: "Quedarme. No un rato. Quedarme, y merecer que te quedes.",
  },
] as const;

const SONG_ID = "lg0TLCr2W0Q";
const SONG_URL = "https://youtu.be/lg0TLCr2W0Q?si=lgVa_TL9NXhwmrF_";

type YtPlayer = {
  playVideo: () => void;
  pauseVideo: () => void;
  mute: () => void;
  unMute: () => void;
  setVolume: (volume: number) => void;
};

type YtEvent = { target: YtPlayer; data: number };

declare global {
  interface Window {
    YT?: {
      Player: new (
        id: string,
        options: {
          width?: string;
          height?: string;
          videoId: string;
          playerVars?: Record<string, string | number>;
          events?: {
            onReady?: (event: YtEvent) => void;
            onStateChange?: (event: YtEvent) => void;
          };
        },
      ) => YtPlayer;
    };
    onYouTubeIframeAPIReady?: () => void;
  }
}

function useBackgroundSong() {
  const playerRef = useRef<YtPlayer | null>(null);
  const wantRef = useRef(true);
  const heardRef = useRef(false);
  const [audible, setAudible] = useState(false);

  useEffect(() => {
    let cancelled = false;

    const mount = () => {
      if (cancelled || playerRef.current || !window.YT?.Player) return;
      if (!document.getElementById("yt-bg")) return;
      playerRef.current = new window.YT.Player("yt-bg", {
        width: "128",
        height: "72",
        videoId: SONG_ID,
        playerVars: {
          autoplay: 1,
          loop: 1,
          playlist: SONG_ID,
          rel: 0,
          playsinline: 1,
          modestbranding: 1,
        },
        events: {
          onReady: (event) => {
            if (heardRef.current) {
              event.target.unMute();
              event.target.setVolume(100);
            } else {
              event.target.mute();
            }
            if (wantRef.current) event.target.playVideo();
          },
          onStateChange: (event) => {
            if (event.data === 0 && wantRef.current) event.target.playVideo();
          },
        },
      });
    };

    if (window.YT?.Player) mount();
    else {
      const previous = window.onYouTubeIframeAPIReady;
      window.onYouTubeIframeAPIReady = () => {
        previous?.();
        mount();
      };
      if (!document.querySelector("script[data-yt-api]")) {
        const tag = document.createElement("script");
        tag.src = "https://www.youtube.com/iframe_api";
        tag.dataset.ytApi = "1";
        document.head.appendChild(tag);
      }
    }

    const arm = () => {
      if (!wantRef.current) return;
      heardRef.current = true;
      setAudible(true);
      const player = playerRef.current;
      if (!player) return;
      player.unMute();
      player.setVolume(100);
      player.playVideo();
    };
    window.addEventListener("pointerdown", arm);

    return () => {
      cancelled = true;
      window.removeEventListener("pointerdown", arm);
    };
  }, []);

  const play = () => {
    wantRef.current = true;
    heardRef.current = true;
    setAudible(true);
    const player = playerRef.current;
    if (!player) return;
    player.unMute();
    player.setVolume(100);
    player.playVideo();
  };

  const pause = () => {
    wantRef.current = false;
    heardRef.current = false;
    setAudible(false);
    playerRef.current?.pauseVideo();
  };

  return { play, pause, playing: audible };
}

const INDEX = [
  { id: "verdad", label: "De verdad" },
  { id: "nuevo", label: "Lo nuevo" },
  { id: "mereces", label: "La honestidad" },
  { id: "paciencia", label: "Paciencia" },
  { id: "infinito", label: "El infinito" },
  { id: "cancion", label: "La canción" },
] as const;

function scrollToId(id: string) {
  const reduce = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
  document.getElementById(id)?.scrollIntoView({
    behavior: reduce ? "auto" : "smooth",
    block: "start",
  });
}

function Reveal({ children, className = "" }: { children: ReactNode; className?: string }) {
  const ref = useRef<HTMLDivElement>(null);
  const [shown, setShown] = useState(false);

  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    if (window.matchMedia("(prefers-reduced-motion: reduce)").matches) {
      setShown(true);
      return;
    }
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry?.isIntersecting) {
          setShown(true);
          observer.disconnect();
        }
      },
      { threshold: 0.18, rootMargin: "0px 0px -6% 0px" },
    );
    observer.observe(el);
    return () => observer.disconnect();
  }, []);

  return (
    <div ref={ref} className={`reveal${shown ? " is-in" : ""}${className ? ` ${className}` : ""}`}>
      {children}
    </div>
  );
}

function Home() {
  const [progress, setProgress] = useState(0);
  const [open, setOpen] = useState<Record<string, boolean>>({});
  const allOpen = VOWS.every((vow) => open[vow.id]);
  const song = useBackgroundSong();

  useEffect(() => {
    const onScroll = () => {
      const full = document.documentElement.scrollHeight - window.innerHeight;
      setProgress(full > 0 ? Math.min(1, window.scrollY / full) : 0);
    };
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  return (
    <main>
      <div
        className="fixed inset-x-0 top-0 z-40 h-0.5 origin-left bg-rust"
        style={{ transform: `scaleX(${progress})` }}
        aria-hidden
      />

      <section className="grid min-h-dvh lg:grid-cols-2">
        <div className="relative bg-night lg:min-h-dvh">
          <img
            src="/nosotros.jpg"
            alt="Los dos, juntos, sonriendo"
            className="cover-photo h-auto w-full lg:absolute lg:inset-0 lg:h-full"
          />
        </div>
        <div className="flex flex-col justify-end bg-night px-6 pt-14 pb-28 text-paper sm:px-10 lg:justify-center lg:px-16 lg:py-20">
          <p className="text-xs font-medium tracking-widest text-brass uppercase">
            Una carta, no un mensaje
          </p>
          <h1 className="mt-5 font-display text-6xl leading-none font-medium text-balance text-paper italic sm:text-7xl">
            Para ti
          </h1>
          <p className="mt-6 max-w-sm text-lg leading-relaxed text-pretty text-paper/80">
            Ordené lo que siento para que puedas leerlo despacio. Sin prisa. Sin tener que adivinar entre
            líneas.
          </p>
          <button
            type="button"
            onClick={() => {
              song.play();
              scrollToId("carta");
            }}
            className="mt-10 inline-flex min-h-11 w-fit items-center rounded-seal bg-rust px-7 text-sm tracking-wide text-paper"
          >
            Leer la carta
          </button>
        </div>
      </section>

      <article id="carta" className="bg-paper text-ink">
        <div className="measure mx-auto max-w-xl px-6 py-20 sm:py-28">
          <Reveal>
            <p className="font-display text-2xl leading-snug text-balance italic sm:text-3xl">
              Hay cosas que se me escapan cuando te hablo. Aquí no. Aquí te las dejo como son.
            </p>
          </Reveal>

          <nav className="mt-12 flex flex-wrap gap-2" aria-label="Partes de la carta">
            {INDEX.map((item) => (
              <button
                key={item.id}
                type="button"
                onClick={() => scrollToId(item.id)}
                className="inline-flex min-h-11 items-center rounded-seal border border-line px-4 text-sm text-muted"
              >
                {item.label}
              </button>
            ))}
          </nav>

          <div className="mt-16 space-y-20">
            {CHAPTERS.map((chapter) => (
              <section key={chapter.id} id={chapter.id} className="scroll-mt-10">
                <Reveal>
                  <p className="text-xs font-medium tracking-widest text-rust uppercase">{chapter.num}</p>
                  <h2 className="mt-3 font-display text-4xl leading-none font-medium text-balance sm:text-5xl">
                    {chapter.title}
                  </h2>
                  <div className="rule mt-6" />
                  <div className="mt-8 space-y-5 text-lg leading-relaxed">
                    {chapter.paragraphs.map((paragraph) => (
                      <p key={paragraph}>{paragraph}</p>
                    ))}
                  </div>
                </Reveal>
              </section>
            ))}
          </div>

          <Reveal className="mt-20">
            <blockquote className="border-l border-brass pl-6">
              <p className="font-display text-3xl leading-snug text-balance italic sm:text-4xl">
                «Contigo no quiero un pedazo. Contigo quiero todo.»
              </p>
            </blockquote>
          </Reveal>
        </div>
      </article>

      <section id="infinito" className="scroll-mt-10 bg-night text-paper">
        <div className="mx-auto max-w-xl px-6 py-24 sm:py-32">
          <Reveal>
            <p className="text-xs font-medium tracking-widest text-brass uppercase">05 · Contigo quiero</p>
            <h2 className="mt-4 max-w-md font-display text-4xl leading-tight font-medium text-balance sm:text-5xl">
              El mundo. El universo. El infinito.
            </h2>
            <p className="mt-6 max-w-md leading-relaxed text-pretty text-paper/75">
              Toca cada una. No es una lista: es lo que te estoy ofreciendo, de lo más cercano a lo que no
              termina.
            </p>
          </Reveal>

          <ul className="mt-12">
            {VOWS.map((vow) => {
              const isOpen = Boolean(open[vow.id]);
              return (
                <li key={vow.id} className="border-t border-paper/15">
                  <button
                    type="button"
                    aria-expanded={isOpen}
                    onClick={() => setOpen((current) => ({ ...current, [vow.id]: !current[vow.id] }))}
                    className="flex min-h-16 w-full items-center justify-between gap-4 py-5 text-left"
                  >
                    <span className="font-display text-4xl leading-none italic sm:text-5xl">{vow.word}</span>
                    <span className="text-xs tracking-widest text-brass uppercase">
                      {isOpen ? "cerrar" : "abrir"}
                    </span>
                  </button>
                  <div className={`fold${isOpen ? " is-open" : ""}`}>
                    <div className="fold-inner">
                      <p className="max-w-md pb-6 leading-relaxed text-pretty text-paper/80">{vow.line}</p>
                    </div>
                  </div>
                </li>
              );
            })}
          </ul>

          <div className={`fold${allOpen ? " is-open" : ""}`}>
            <div className="fold-inner">
              <p className="mt-8 font-display text-2xl leading-snug text-balance italic">
                Si el infinito es demasiado grande para prometerlo de una vez, empecemos por quedarnos. Un
                día. Y otro. Y otro.
              </p>
            </div>
          </div>
        </div>
      </section>

      <section id="cierre" className="bg-paper text-ink">
        <div className="measure mx-auto max-w-xl px-6 pt-20 pb-36 sm:pt-28 sm:pb-40">
          <Reveal>
            <figure className="print mx-auto max-w-sm">
              <img src="/nosotros.jpg" alt="Los dos, en la misma noche" className="aspect-4/5 w-full object-cover object-top" />
              <figcaption className="mt-4 text-center font-display text-lg leading-snug italic">
                Esta foto no alcanza a decirlo. Pero es verdad: estábamos ahí, juntos, y yo ya lo sabía.
              </figcaption>
            </figure>
          </Reveal>

          <Reveal className="mt-16">
            <div id="cancion" className="scroll-mt-10">
              <p className="text-xs font-medium tracking-widest text-rust uppercase">06 · Para escuchar</p>
              <h2 className="mt-3 font-display text-4xl leading-none font-medium text-balance sm:text-5xl">
                Entre vos y yo
              </h2>
              <p className="mt-6 text-lg leading-relaxed">
                Va sonando de fondo mientras lees. Es de Los Caligaris: lo que yo quiero que sepas, dicho en
                una canción.
              </p>
              <a
                href={SONG_URL}
                target="_blank"
                rel="noreferrer"
                className="mt-6 inline-flex min-h-11 items-center text-sm tracking-wide text-rust underline decoration-brass underline-offset-4"
              >
                Abrir la canción
              </a>
            </div>
          </Reveal>

          <Reveal className="mt-16">
            <div className="space-y-5 text-lg leading-relaxed">
              <p>No te pido que me esperes para siempre.</p>
              <p>
                Te pido que, si algo de esto también es tuyo, me des el tiempo de poner en orden lo que soy.
                Porque contigo quiero el mundo, el universo y el infinito. Y quiero merecerlos.
              </p>
              <p>No prometo ser perfecto. Prometo no querer esto a medias.</p>
            </div>
            <div className="rule mt-12" />
            <p className="mt-8 font-display text-3xl leading-tight italic">
              Con todo lo que soy.
              <br />
              Y con lo que todavía estoy aprendiendo a ser.
            </p>
            <p className="mt-8 text-sm tracking-widest text-muted uppercase">Para ti, de mí</p>
          </Reveal>
        </div>
      </section>

      <aside className="fixed inset-x-3 bottom-3 z-30 border border-paper/15 bg-night text-paper shadow-none sm:inset-x-auto sm:right-4 sm:bottom-4 sm:w-96">
        <div className="flex items-center gap-3 p-2">
          <div className="h-16 w-28 shrink-0 overflow-hidden bg-night-soft">
            <div id="yt-bg" />
          </div>
          <div className="min-w-0 flex-1">
            <p className="text-xs font-medium tracking-widest text-brass uppercase">De fondo</p>
            <p className="truncate font-display text-lg leading-tight italic">Entre vos y yo</p>
          </div>
          <button
            type="button"
            onClick={song.playing ? song.pause : song.play}
            className="inline-flex min-h-11 shrink-0 items-center rounded-seal bg-rust px-4 text-sm tracking-wide text-paper"
          >
            {song.playing ? "Pausa" : "Escuchar"}
          </button>
        </div>
      </aside>
    </main>
  );
}
